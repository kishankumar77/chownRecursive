#!/usr/software/bin/perl5.8.8

package BBInit;

use strict;
use warnings;

require Exporter;
our @ISA = qw(Exporter);

our $BB_CMD_SUR = '/u/dummyuser/chownExt/sur';
our $BB_LOGFILE = 'logfile';
our $BB_PFIND = '/u/dummyuser/chownExt/pfind';
our $BB_FILELIST                   = ".filelist";
our $BB_CMD_CAT                    = "/bin/cat";
our $BB_CMD_TR                     = "/usr/bin/tr";
our $BB_CMD_XARGS                  = "/usr/software/bin/xargs";
our $BB_CMD_CUSTOM_CHOWN           = "/u/dummyuser/chownExt/simple_chown";

our @EXPORT = qw($BB_CMD_SUR $BB_LOGFILE $BB_PFIND $BB_CMD_SUR $BB_LOGFILE $BB_PFIND $BB_FILELIST $BB_CMD_CAT $BB_CMD_TR $BB_CMD_XARGS $BB_CMD_CUSTOM_CHOWN );

1;
