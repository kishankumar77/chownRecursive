#!/usr/software/bin/perl5.8.8
package BBSur;
use strict;
use warnings;
use FindBin;
use English '-no_match_vars';
use Data::Dumper;
use lib '/u/dummy/chownExt/lib';
use BBInit;

my $user;

sub CallSur {
###########################################################################
    # This method calls sur.
    # It checks the return value.  If the sur command was interrupted
    # it sends the same signal to the current process.
############################################################################
    my (@params) = @_;

    my $command = $params[0];
	#sur_DoChown will run as build user and change the ownership of ws files/dirs.
    $user = 'root' if($command eq 'sur_DoChown' || $command eq 'sur_DoDeleteGit');

    my $ret = system($BB_CMD_SUR, $FindBin::Bin, $user, 'CMD', @params, $BB_LOGFILE);
    if ($ret > 0 && $ret < 127) {

        # the sur command was interrupted - send this process a signal
        print("Sur Command interrupted (sig $ret)\n");
        kill('INT', $$);
    } elsif ($ret != 0) {
        $ret = $ret >> 8;
    }
    return ($ret);
} ## end sub CallSur


sub CallSurAsUser {
###########################################################################
    # This method calls sur.
    # It checks the return value.  If the sur command was interrupted
    # it sends the same signal to the current process.
    #
    # NOTE: The user name must be the last parm passed in.
############################################################################
    my (@params) = @_;

    my $user = $params[-1];

    my $ret = system($BB_CMD_SUR, $FindBin::Bin, $user, 'CMD', @params, $BB_LOGFILE);
    if ($ret > 0 && $ret < 127) {

        # the sur command was interrupted - send this process a signal
        print("Sur Command interrupted (sig $ret)\n");
        kill('INT', $$);
    } elsif ($ret != 0) {
        $ret = $ret >> 8;
    }
    return ($ret);
} ## end sub CallSurAsUser
1;
