#include <string.h>
#include <stdlib.h>
#include <stdio.h>
#include <libgen.h>
#include <unistd.h>
#include <sys/types.h>
#include <pwd.h>

main (int     argc,
      char ** argv)
{
    int 	    id ;
    char	  * bindir;
    char	  * suser;
    int 	    suid;
    char	    surcmd [100];
    char	    p4env [100];
    struct passwd * pw;

    if (argc <= 3)
    {
	fprintf (stderr, "Usage: %s: <bindir> <user> <sur_cmd> [<args>]\n",
	         argv[0]);
	exit (1);
    }

    bindir = argv[1];
    suser = argv[2];

    pw = getpwnam (suser);
    if (pw == NULL)
    {
	perror ("getpwnam failed");
	exit (1);
    }

    suid = pw->pw_uid;

    setuid (suid);
    id = getuid ();

    if (id != suid)
    {
	printf ("%s: Sur command failed to set UID to %d\n", argv[0], suid);
	exit (1);
    }

    p4env[0] = '\0';
    strcat (p4env, bindir);
    strcat (p4env, "/../P4ENV");

    surcmd[0] = '\0';
    if (access (p4env, F_OK) == 0)
    {
	strcat (surcmd, bindir);
	strcat (surcmd, "/../sur/sur_dispatch");
    }
    else
    {
	strcat (surcmd, "/u/dummyuser/chownExt/sur_dispatch");
    }

    execv (surcmd, &argv[2]);
    fprintf (stderr, "surcmd %s\n", surcmd);
    perror ("sur: exec failed");
    exit (1);
}
