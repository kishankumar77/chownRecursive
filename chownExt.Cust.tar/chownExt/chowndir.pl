#!/usr/software/bin/perl5.8.8

use strict;
use warnings;

use Getopt::Long;

use lib '/u/dummyuser/chownExt/lib';
use BBSur;

#my ($client_dir,$excl_dir, $BB_USER, $BB_BUILDUSER ); #< this should be passed from command line  >

my ( $client_dir, $to_user, $excl_dir, $help );

if (
        !&GetOptions(
            "help|h"                    => \$help,
            "dirpath=s"                 => \$client_dir,
            "touser=s"                  => \$to_user,
            "excludedir=s"              => \$excl_dir,
            )   
   ) { 
        &Usage;
}   

if ($help) {
        &Usage;
    } 


$excl_dir = '' unless(defined $excl_dir);
print("Directory Inputted for changing ownership => $client_dir\nDirectories needs to excluded in top level => $excl_dir\nChange Ownership of directory to user => $to_user\n");
my $starttime = time();

print "Start time of chown: $starttime\n";
&BBSur::CallSur("sur_DoChown", $client_dir, "dummy_user", $to_user , $excl_dir);

my $endtime = time();
print "End time of chown: $endtime\n";

my $totaltime = $endtime - $starttime ;
print "Duration in Seconds: <$totaltime>\n";

sub Usage {
#########################################################################
    # This just prints script usage via a "here" document, and exits.
#########################################################################

    print <<EOM;

Description:
    This script will change the files/dirs ownership within a directory
Syntax:
    chowndir.pl --dirpath="/u/testdir/mydir" --touser="user2" --excludedir="testdir1"
                                  
EOM
    exit(0);
}    #Usage
