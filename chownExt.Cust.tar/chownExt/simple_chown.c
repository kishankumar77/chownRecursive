/*
 * a specialized version of /bin/chown that takes a numeric user id
 * and a list of files to chown
 * 
 * avoids fchdir() and lstat() system calls
 * used by /bin/chown
 */

#include <sys/types.h>
#include <unistd.h>
#include <stdlib.h>
#include <stdio.h>

int main(
	 int argc,
	 char **argv)
{
    int ix;
    int id;

    if (argc < 3 ) {
        fprintf(stderr, "Invalid number of arguments.  %s <user id> <file list>\n", argv[0]);
	exit(1);
    }

    id = atoi(argv[1]);

    for(ix=2; argv[ix]; ix++) {
	(void) lchown(argv[ix], id, -1);
    }
    return 0;
}
